CKEDITOR.plugins.setLang('lineheight','ar', {
    title: 'خط الطول'
} );
